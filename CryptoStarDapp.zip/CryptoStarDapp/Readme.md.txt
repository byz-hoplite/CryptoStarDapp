Truffle version: Truffle v5.4.14
OpenZeppelin:    "openzeppelin-solidity": "^4.3.2",
Token Name:      Star Notary
Token Symbol:    $STAR
Token Address:   0x32BEaE4D4a30764937eDDA5cB810114bBFd86e6c

*
'node_modules' folder and .secret file have been excluded